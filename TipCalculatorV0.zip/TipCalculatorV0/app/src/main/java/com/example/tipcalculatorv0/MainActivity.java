package com.example.tipcalculatorv0;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    private TipCalculator tipCalc;
    private EditText billEditText;
    private EditText tipEditText;
    private NumberFormat money = NumberFormat.getCurrencyInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tipCalc = new TipCalculator(0.2f, 100.0f);

        setContentView(R.layout.activity_main);

        billEditText = (EditText) findViewById(R.id.amount_bill_hint);
        tipEditText = (EditText) findViewById(R.id.amount_tip_percent_hint);

        TextChangeHandler tch = new TextChangeHandler();

        billEditText.addTextChangedListener(tch);
        tipEditText.addTextChangedListener(tch);

    }

    public void calculate() {

        String billString = billEditText.getText().toString();
        String tipString = tipEditText.getText().toString();

        TextView tipTextView = (TextView) findViewById(R.id.amount_tip);
        TextView totalTextView = (TextView) findViewById(R.id.amount_total);

        try {

            float billAmount = Float.parseFloat(billString);
            int tipPercentage = Integer.parseInt(tipString);

            tipCalc.setBill(billAmount);
            tipCalc.setTip(0.01f * tipPercentage);

            float tip = tipCalc.TipAmount();
            float amount = tipCalc.TotalAmount();

            tipTextView.setText(money.format(tip));
            totalTextView.setText(money.format(amount));

        } catch (NumberFormatException nfe) {

        }
    }


    private class TextChangeHandler implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            calculate();
        }
    }
}