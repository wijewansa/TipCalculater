package com.example.tipcalculatorv0;

public class TipCalculator {
    private float tip;
    private float bill;

    public TipCalculator(float newTip, float newBill)
    {
       tip=newTip;
       bill=newBill;
    }

    public void setTip(float newTip)
    {
        if(newTip>0)
        {
            tip=newTip;
        }
    }
    public void setBill(float newBill)
    {
        if(newBill>0)
        {
            bill=newBill;
        }
    }

    public float getNewTip() {
        return tip;
    }

    public float getNewBill() {
        return bill;
    }

    public float TipAmount()
    {
        return (bill*tip);
    }
    public float TotalAmount()
    {
        return (bill+TipAmount());
    }

}
